
//{{BLOCK(tileedit)

//======================================================================
//
//	tileedit, 216x8@4, 
//	+ palette 16 entries, not compressed
//	+ 27 tiles not compressed
//	Total size: 32 + 864 = 896
//
//	Time-stamp: 2007-09-19, 10:12:11
//	Exported by Cearn's GBA Image Transmogrifier
//	( http://www.coranac.com )
//
//======================================================================

#ifndef __TILEEDIT__
#define __TILEEDIT__

#define tileeditPalLen 32
extern const unsigned short tileeditPal[16];

#define tileeditTilesLen 864
extern const unsigned short tileeditTiles[432];

#endif // __TILEEDIT__

//}}BLOCK(tileedit)
