extern const u8 DSkill_raw_end[];
extern const u8 DSkill_raw[];
extern const u32 DSkill_raw_size;
