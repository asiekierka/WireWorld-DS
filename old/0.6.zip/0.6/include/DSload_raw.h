extern const u8 DSload_raw_end[];
extern const u8 DSload_raw[];
extern const u32 DSload_raw_size;
