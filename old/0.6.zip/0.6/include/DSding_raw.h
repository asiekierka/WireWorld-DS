extern const u8 DSding_raw_end[];
extern const u8 DSding_raw[];
extern const u32 DSding_raw_size;
