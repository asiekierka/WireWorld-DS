extern const u8 DSnew_raw_end[];
extern const u8 DSnew_raw[];
extern const u32 DSnew_raw_size;
