extern "C" void memcpy32(void *dst, const void *src, u32 wdcount);
extern "C" void memset32(void *dst, u32 src, u32 wdn);
