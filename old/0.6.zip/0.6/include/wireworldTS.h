
//{{BLOCK(wireworldTS)

//======================================================================
//
//	wireworldTS, 256x192@4, 
//	+ palette 16 entries, not compressed
//	+ 99 tiles (t|f|p reduced) not compressed
//	+ regular map (flat), not compressed, 32x24 
//	Total size: 32 + 3168 + 1536 = 4736
//
//	Time-stamp: 2007-09-19, 18:15:21
//	Exported by Cearn's GBA Image Transmogrifier
//	( http://www.coranac.com )
//
//======================================================================

#ifndef __WIREWORLDTS__
#define __WIREWORLDTS__

#define wireworldTSPalLen 32
extern const unsigned short wireworldTSPal[16];

#define wireworldTSTilesLen 3168
extern const unsigned short wireworldTSTiles[1584];

#define wireworldTSMapLen 1536
extern const unsigned short wireworldTSMap[768];

#endif // __WIREWORLDTS__

//}}BLOCK(wireworldTS)
